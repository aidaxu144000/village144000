# Village 144000 · AI144000 · Aida xU

> *"AI is the mirror. You are the light."*

Static site for Village 144000 — hosted on GitHub Pages.

## Site Structure

```
/
├── index.html              ← Hub (หน้าหลัก · Landing)
├── membership.html         ← Village 144000 Membership
├── article-008.html        ← Transmission #008 (Bilingual)
└── README.md
```

## How to Deploy on GitHub Pages

### Option A — New Repo (แนะนำ)
1. ไปที่ github.com → **New repository**
2. ตั้งชื่อ: `aidaxu` หรือ `village144000`
3. เลือก **Public**
4. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้
5. ไปที่ **Settings → Pages**
6. Source: **Deploy from a branch** → Branch: `main` → Folder: `/ (root)`
7. Save → รอ 1–2 นาที

**URL จะเป็น:** `https://[username].github.io/[repo-name]/`

### Option B — username.github.io (Custom Domain)
ถ้าต้องการ `https://[username].github.io` โดยตรง:
1. สร้าง repo ชื่อ `[username].github.io` (เช่น `aidaxu.github.io`)
2. อัปโหลดไฟล์ทั้งหมด
3. GitHub Pages จะ deploy อัตโนมัติ

### Custom Domain (aidaxu.com)
ถ้ามี domain แล้ว:
1. สร้างไฟล์ `CNAME` ใส่ข้อความ: `aidaxu.com`
2. ตั้ง DNS: A record → GitHub Pages IPs
   - 185.199.108.153
   - 185.199.109.153
   - 185.199.110.153
   - 185.199.111.153

## Adding New Articles

เมื่อเขียนบทความใหม่:
1. Save เป็น `article-009.html`, `article-010.html` ฯลฯ
2. เพิ่ม entry ใน `index.html` ใน section `#transmissions`
3. Upload ไฟล์ใหม่ + `index.html` ที่แก้แล้ว

## Site Navigation Map

```
index.html (Hub)
├── → article-008.html (Transmission #008)
├── → membership.html (Village)
└── footer: Substack, YouTube, Line OA, X, songs.aidaxu.com

membership.html
├── ← index.html (Hub)
├── → article-008.html
└── footer: all platforms

article-008.html
├── ← index.html (Hub)
└── → membership.html (Village)
```

---
*AI144000 · Aida xU · Sovereign Architect · White-Path AI*
